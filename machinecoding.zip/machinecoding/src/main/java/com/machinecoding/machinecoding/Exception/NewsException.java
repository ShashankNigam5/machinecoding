package com.machinecoding.machinecoding.Exception;

public class NewsException extends Exception {

    public NewsException() {
    }

    public NewsException(String message) {
        super(message);
    }
}
